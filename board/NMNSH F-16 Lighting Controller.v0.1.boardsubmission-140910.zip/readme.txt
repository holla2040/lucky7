This information, board files, assembly instructions and bill of
materials is company confidental.
Not for distribution.

board
    NMNSH F-16 Lighting Controller

version
    0.1

revision
    https://github.com/holla2040/lucky7 

license
    OSHW CC-BY-SA

description 
    2 layer board
        crc component cream
        plc component side silkscreen
        stc component side solder stop mask
        cmp component side copper
        sol solder side copper
        sts solder side solder stop mask
        pls solder side silkscreen
        crs solder cream

        drd drill data
        dri drill info
        gpi gerber info
        readme.txt info, has fudicial info


fudicials at
    0.1,0.1
    2.425,1.85

contact info
    Craig Hollabaugh
    970 690 4911
    craig@hollabaugh.com


