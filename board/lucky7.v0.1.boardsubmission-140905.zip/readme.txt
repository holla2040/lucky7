This information, board files, assembly instructions and bill of
materials is company confidental.
Not for distribution.

board
    Lucky7

version
    0.1

revision
    https://github.com/holla2040/lucky7 

license
    OSHW CC-BY-SA

description - iteadstudio
    Silk Top:                   pcbname.GTO
    Solder Stop Mask top:       pcbname.GTS
    Top layer:                  pcbname.GTL
    Bottom layer:               pcbname.GBL
    Solder Stop Mask Bottom:    pcbname.GBS
    Silk Bottom:                pcbname.GBO
    NC Drill:                   pcbname.TXT

fudicials at
    0.1,0.1
    2.425,1.85

contact info
    Craig Hollabaugh
    970 690 4911
    craig@hollabaugh.com


